export async function GET(request: Request) {
    const documentList:Array<any>=[
        {id:1,tag:"document"},
        {id:2,tag:"scan"},
        {id:3,tag:"approval"},
        {id:4,tag:"profile"}
    ]
    return Response.json({ documentList },{
        status:200,
        headers:{
            'Content-Type':"application/json"
        }
    })
  }