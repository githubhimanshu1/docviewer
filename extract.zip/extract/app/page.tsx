import Image from "next/image";
import Drawer from "./components/Drawer";

export default function Home() {
  return (
      <Drawer/>
  );
}
