import { Carousel } from "./Carousel";

export const Hero=()=>{
    return (
        <div className="hero min-h-[400px] bg-gray-100 m-auto w-auto">
  <div className="hero-content text-center w-[1100px]">
    <div className="max-w-2xl">
    <img src="anim.gif" className="m-auto"/>
      <h1 className="text-5xl font-bold text-zinc-800 m-auto">DocExtract</h1>
      <p className="py-6 text-zinc-900">With DocExtract by your side, you can bid farewell to receipt-related headaches. Whether you're managing personal expenses or overseeing business finances, our app is the ultimate companion for accurate and hassle-free receipt scanning. Download now and unlock the secrets hidden within your receipts!.</p>
     
     
      <Carousel/>
      <label htmlFor="my-drawer" className="btn btn-primary drawer-button">Open drawer</label>
    </div>
  </div>
</div>
    )
}
export default Hero;