import { FontAwesomeIcon,FontAwesomeIconProps } from '@fortawesome/react-fontawesome'
import { faHeart,faWandMagicSparkles ,faSnowflake,faFileShield} from '@fortawesome/free-solid-svg-icons';
export const Carousel=()=>{
    return (
        <div className="carousel rounded-box h-[200px] -ml-12">
  <div className="carousel-item w-[200px] bg-white shadow-lg justify-center">
  <div className="w-full h-24 justify-center bg-[#5751bb]"><FontAwesomeIcon icon={faWandMagicSparkles} className='text-sm text-[#fff] h-[48px] px-2 py-2 bg-transparent mt-8 m-auto'/></div> 
 

  </div> 
  <div className="carousel-item w-[200px] bg-white shadow-lg justify-center">
  <div className="w-full h-24 justify-center bg-[#6660cd]"><FontAwesomeIcon icon={faSnowflake} className='text-sm text-[#fff] h-[48px] px-2 py-2 bg-transparent mt-8 m-auto'/></div> 
  </div> 
  <div className="carousel-item w-[200px] bg-white shadow-lg justify-center">
  <div className="w-full h-24 justify-center bg-[#736dde]"><FontAwesomeIcon icon={faFileShield} className='text-sm text-[#fff] h-[48px] px-2 py-2 bg-transparent mt-8 m-auto'/></div> 
  </div> 
  <div className="carousel-item w-[200px] bg-white shadow-lg justify-center">
  <div className="w-full h-24 justify-center bg-[#8883ed]"><FontAwesomeIcon icon={faFileShield} className='text-sm text-[#fff] h-[48px] px-2 py-2 bg-transparent mt-8 m-auto'/></div> 
  </div> 

</div>
    );
}