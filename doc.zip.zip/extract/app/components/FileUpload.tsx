import { useState, ChangeEvent } from 'react';
import axios from 'axios';

interface UploadedFile {
    url: string;
    key: string;
}

export default function FileUpload() {
    const [files, setFiles]:any = useState();
    const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

    const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            const file=e.target.files;
            setFiles(file[0]);
        }
    };

    const handleUpload = async () => {
        const formData = new FormData();
        formData.append('files', files);
       
        try {
       fetch("/api/multiLoad", {
                method: "POST",
                body: formData,
              }).then(response=>response.json()).then((data)=>{
                console.log(data);
                setUploadedFiles(data.files);
              })
           
        } catch (error) {
            console.error('Error uploading files:', error);
        }
    };

    return (
        <div className="container mx-auto p-4">
            <div className="card shadow-lg p-4">
                <h2 className="card-title">Upload Files</h2>
                <input
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="file-input file-input-bordered w-full max-w-xs mt-4"
                />
                <button
                    onClick={handleUpload}
                    className="btn btn-primary mt-4"
                >
                    Upload
                </button>
            </div>
            <div className="mt-4">
                <h3 className="text-lg font-bold">Uploaded Files:</h3>
                <ul className="list-disc list-inside">
                    {uploadedFiles.map((file) => (
                        <li key={file.key}>
                            <a href={file.url} target="_blank" rel="noopener noreferrer">
                                {file.key}
                            </a>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
}
