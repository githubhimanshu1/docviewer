export default function Upload(){
const handleFileChange=()=>{
const fileInput:any = document.getElementById("fileInput"); // Replace with your HTML element ID
const file:any = fileInput.files[0];
}
const handleUpload=()=>{
const fileInput:any = document.getElementById("fileInput"); // Replace with your HTML element ID
const file = fileInput.files[0];

const formData = new FormData();
formData.append("file", file);

fetch("/api/multiLoad", {
  method: "POST",
  body: formData,
})
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error(error));
}

const formData = new FormData();
return (
    <div className="container mx-auto p-4">
    <div className="card shadow-lg p-4">
        <h2 className="card-title">Upload Files</h2>
        <input
            type="file"
            multiple
            onChange={handleFileChange}
            className="file-input file-input-bordered w-full max-w-xs mt-4"
            id="fileInput"
        />
        <button
            onClick={handleUpload}
            className="btn btn-primary mt-4"
        >
            Upload
        </button>
    </div>
    <div className="mt-4">
        <h3 className="text-lg font-bold">Uploaded Files:</h3>
        {/* <ul className="list-disc list-inside">
            {uploadedFiles.map((file) => (
                <li key={file.key}>
                    <a href={file.url} target="_blank" rel="noopener noreferrer">
                        {file.key}
                    </a>
                </li>
            ))}
        </ul> */}
    </div>
</div>
);
}