"use client"
import { useEffect, useState } from "react";
import Hero from "./Hero";

const Drawer=()=>{
  const [menuOption,setMenuOption]:Array<any>=useState([])
  useEffect(()=>{
    fetch("/api/settings").then(response=>response.json()).then(data=>setMenuOption(data.documentList)).catch(err=>console.error("error occured"));
  },[]);
return (<div className="drawer">
<input id="my-drawer" type="checkbox" className="drawer-toggle" />
<div className="drawer-content h-screen bg-transparent text-center">
 <Hero/>
  {/* Page content here */}

</div> 
<div className="drawer-side">
  <label htmlFor="my-drawer" aria-label="close sidebar" className="drawer-overlay"></label>
  <ul className="menu p-4 w-80 min-h-full bg-base-200 text-base-content">
    {/* Sidebar content here */}
    <li><a>Sidebar Item 1</a></li>
    <li><a>Sidebar Item 2</a></li>
    {
      menuOption.map((option:any)=>(
        <li>{option["tag"]}</li>
      ))
    }
    
  </ul>
</div>
</div>)
}
export default Drawer;
