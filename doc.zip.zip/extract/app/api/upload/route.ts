import type { NextApiRequest, NextApiResponse } from 'next';
import { S3Client } from '@aws-sdk/client-s3';
import multer from 'multer';
import multerS3 from 'multer-s3';
import { createConnection } from 'snowflake-sdk';
import { NextConnect } from 'next-connect';

interface MulterRequest extends NextApiRequest {
  files: Express.MulterS3.File[];
}

const s3 = new S3Client({
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
  region: process.env.AWS_REGION!,
});

const upload = multer({
  storage: multerS3({
    s3,
    bucket: process.env.AWS_S3_BUCKET!,
    key: (req, file, cb) => {
      cb(null, `${Date.now().toString()}-${file.originalname}`);
    },
  }),
});

const uploadMiddleware = upload.array('files');

const post = async (req: MulterRequest, res: NextApiResponse) => {
  console.log(req.body);
  const files = req.files.map((file) => ({
    url: file.location,
    key: file.key,
  }));

  try {
    // Initialize Snowflake connection
    const connection = createConnection({
      account: process.env.SNOWFLAKE_ACCOUNT!,
      username: process.env.SNOWFLAKE_USERNAME!,
      password: process.env.SNOWFLAKE_PASSWORD!,
      warehouse: process.env.SNOWFLAKE_WAREHOUSE!,
      database: process.env.SNOWFLAKE_DATABASE!,
      schema: process.env.SNOWFLAKE_SCHEMA!,
    });

    // Connect to Snowflake
    connection.connect((err, conn) => {
      if (err) {
        console.error('Unable to connect to Snowflake: ' + err.message);
        res.status(500).json({ error: 'Unable to connect to Snowflake' });
        return;
      } else {
        console.log('Successfully connected to Snowflake.');
      }
    });

    // Create the Snowflake stage if it does not exist
    const createStageQuery = `CREATE STAGE IF NOT EXISTS my_stage`;
    await new Promise<void>((resolve, reject) => {
      connection.execute({
        sqlText: createStageQuery,
        complete: (err) => {
          if (err) {
            console.error('Failed to create stage: ' + err.message);
            reject(err);
          } else {
            console.log('Stage created or already exists.');
            resolve();
          }
        },
      });
    });

    // Upload files to Snowflake stage
    for (const file of files) {
      const copyIntoQuery = `
        COPY INTO @my_stage/${file.key}
        FROM '${file.url}'
        CREDENTIALS = (
          AWS_KEY_ID = '${process.env.AWS_ACCESS_KEY_ID}'
          AWS_SECRET_KEY = '${process.env.AWS_SECRET_ACCESS_KEY}'
        )
        FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"');
      `;

      await new Promise<void>((resolve, reject) => {
        connection.execute({
          sqlText: copyIntoQuery,
          complete: (err) => {
            if (err) {
              console.error('Failed to copy into stage: ' + err.message);
              reject(err);
            } else {
              console.log(`File ${file.key} copied to stage.`);
              resolve();
            }
          },
        });
      });
    }

    res.status(200).json({ files });
  } catch (error) {
    console.error('Error processing files:', error);
    res.status(500).json({ error: 'Error processing files' });
  }
};


export { uploadMiddleware as config, post as POST };


