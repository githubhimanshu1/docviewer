import { createConnection, Connection } from 'snowflake-sdk';

const uploadToStage = async (files) => {
  console.log("uploading..........");

  // Prepare the files array correctly
  const preparedFiles = files.map((file) => ({
    url: file.location,
    key: file.key,
  }));

  try {
    // Initialize Snowflake connection
    const connection= createConnection({
      account: process.env.SNOWFLAKE_ACCOUNT,
      username: process.env.SNOWFLAKE_USERNAME,
      password: process.env.SNOWFLAKE_PASSWORD,
      warehouse: process.env.SNOWFLAKE_WAREHOUSE,
      database: process.env.SNOWFLAKE_DATABASE,
      schema: process.env.SNOWFLAKE_SCHEMA,
    });

    // Connect to Snowflake using a promise
    await new Promise((resolve, reject) => {
      connection.connect((err, conn) => {
        if (err) {
          console.error('Unable to connect to Snowflake: ' + err.message);
          reject(err);
        } else {
          console.log('Successfully connected to Snowflake.');
          resolve();
        }
      });
    });

    // Create the Snowflake stage if it does not exist
    const createStageQuery = `CREATE STAGE IF NOT EXISTS my_stage`;
    await new Promise((resolve, reject) => {
      connection.execute({
        sqlText: createStageQuery,
        complete: (err) => {
          if (err) {
            console.error('Failed to create stage: ' + err.message);
            reject(err);
          } else {
            console.log('Stage created or already exists.');
            resolve();
          }
        },
      });
    });

    // Upload files to Snowflake stage
    for (const file of preparedFiles) {
      const copyIntoQuery = `
        COPY INTO @my_stage/${file.key}
        FROM '${file.url}'
        CREDENTIALS = (
          AWS_KEY_ID = '${process.env.AWS_ACCESS_KEY_ID}'
          AWS_SECRET_KEY = '${process.env.AWS_SECRET_ACCESS_KEY}'
        )
        FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY='"');
      `;

      await new Promise((resolve, reject) => {
        connection.execute({
          sqlText: copyIntoQuery,
          complete: (err) => {
            if (err) {
              console.error('Failed to copy into stage: ' + err.message);
              reject(err);
            } else {
              console.log(`File ${file.key} copied to stage.`);
              resolve();
            }
          },
        });
      });
    }

    return { success: true, files: preparedFiles };
  } catch (error) {
    console.error('Error processing files:', error);
    return { success: false, error: error.message };
  }
};

export default uploadToStage;
