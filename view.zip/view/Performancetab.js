Ext.define("Threesixtydashboard.view.Performancetab",{
	layout:"fit",
	extend:"Ext.tab.Panel",
	require:["Threesixtydashboard.view.SnapshotSelector"],
	alias:"widget.performancetabpanel",
	overflow:"auto",
	items:[
		{
			title:"Performance Snapshots",
			overflow:"auto",
			padding:20,
			baseCls:"cards",
			items:[
				{xtype:"snapshotselector"},

			]
		},
		{
			title:"Session Report",
			padding:20,
			overflow:"auto",
			baseCls:"cards",

			items:[
			{xtype:"reporter"}]
		},
		{
			title:"Snapshot Timeline"
		}
		

	]


});