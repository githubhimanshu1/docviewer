Ext.define("Threesixtydashboard.view.Snapchart",{
	layout:"fit",
	extend:"Ext.container.Container",
	require:["Threesixtydashboard.store.Snapstore"],
	alias:"widget.snapchart",
	items:[
		{

			xtype:"cartesian",
			height:"100%",
			reference:"chart",
			store:{
				type:"snapstore"
			},
		   insetPadding: {
            top: 40,
            bottom: 40,
            left: 20,
            right: 40
        },
        axes: [{
            type: 'numeric',
            position: 'left',
            minimum: 0,
            titleMargin: 20,
            title: {
                text: 'Latency'
            },
           },
       		{
            type: 'numeric',
            position: 'bottom',
            title:{
            	text:"Timeline"
            }
        }],
        series: {
            type: 'bar',
            height:"100%",
            xField: 'timeline',
            yField: 'latency',
            style: {
                minGapWidth: 20
            },
            highlight: {
                strokeStyle: 'black',
                fillStyle: 'gold'
            }
            
        },
		}
		

	]


});