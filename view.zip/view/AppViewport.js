Ext.define("Threesixtydashboard.view.AppViewport",{
	extend:"Ext.container.Viewport",
	requires:["Threesixtydashboard.view.Performancetab"],
	layout:"border",
	items:[
	{
		region:"north",
		baseCls:"header",
		html:"<h2>Performance Dashboard</h2>",
		height:70,
		padding:10
	},
	{
		region:"center",
		items:[
			{xtype:"performancetabpanel"}

		]
	}

 

	]
   


});