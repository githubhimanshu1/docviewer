Ext.define("Threesixtydashboard.view.SnapshotSelector",{
	alias:"widget.snapshotselector",
	extend:"Ext.container.Container",
	width:"100%",
	height:500,

	layout:"vbox",
	items:[
		{
		type:"Ext.form.Panel",
		baseCls:"filtercontainer",
		height:80,
		bodyPadding:20,
		layout:"hbox",
		width:"100%",
		items:[
			{
				xtype:"datefield",
				fieldLabel:"Start Date",
				name:"startdate"
			},
			{
				xtype:"datefield",
				fieldLabel:"End Date",
				name:"enddate",
				margin:"0 0 0 25"
			},
			{
				xtype:"textfield",
				fieldLabel:"User Id",
				margin:"0 0 0 25"
			},
			{
					xtype:"button",
					text:"Snapshot",
					margin:"0 0 0 25"
			}
	

		]

		},
			{
					xtype:"gridpanel",
					baseCls:"snapgrid",
					width:"100%",
				
					columns:[{
							text:"User",
							dataindex:"user",
							width:"25%"
						    },
							{
							text:"Snapshot Id",
							dataindex:"snapshot",
							width:"25%"
						    },{
						    	text:"timestamp",
						    	dataindex:"timestamp",
						    	width:"25%"
						    }
						    ,{
							text:"Country",
							dataindex:"country",
							width:"24%"
						    }]



			}

	]
   


});