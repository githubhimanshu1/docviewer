Ext.define("Threesixtydashboard.view.RequestGrid",{
    extend:"Ext.grid.Panel",
    xtype:"reqgrid",
    width:"100%",
    columns:[
    {dataIndex:"name",text:"name",width:"25%"},
    {dataIndex:"module",text:"module",width:"25%"},
    {dataIndex:"latency",text:"latency",width:"25%"},
    {dataIndex:"timeline",text:"timeline",width:"25%"}


    ],
    store:{
        type:"snapstore"
    }
	});