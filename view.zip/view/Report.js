Ext.define("Threesixtydashboard.view.Report",{
	alias:"widget.report",
	extend:"Ext.container.Container",
	width:"100%",
	
	baseCls:"reportcontainer",
	layout:"vbox",
	items:[
		{
			xtype:"container",
			layout:"hbox",
			width:"100%",
			baseCls:"upper",
			height:300,
			items:[
				{
					xtype:"container",
					width:"70%",
					height:"100%",
					baseCls:"bargraph",
					border:1,
					items:[{
						xtype:"snapchart"
					}],
					padding:10

				},
				{
					xtype:"container",
					width:"30%",
					height:"100%",
						padding:10,
					border:1,
					html:"asdasd",
					baseCls:"pie"
				}

			]

		},
		{
			xtype:"container",
			layout:"hbox",
			width:"100%",
			baseCls:"upper",
			height:300,
			items:[
				{
					xtype:"container",
					width:"70%",
					height:"100%",
					baseCls:"bargraph",
					border:1,
					
					items:[{
						xtype:"gridpanel",
						rowlines:true,
						columnLines:true,
						itemId:"reportgrid",
						type:"memory",
						columns:[
							{dataIndex:"name",text:"Resource/api",width:"25%"},
							{dataIndex:"latency",text:"latency(ms)",width:"25%"},
							{dataIndex:"module",text:"module name",width:"25%"},
							{dataIndex:"timeline",text:"fetchend",width:"24%"}


						],
						store:{type:"snapstore"}
					}]

				},
				{
					xtype:"container",
					width:"30%",
					height:"100%",
						padding:10,
					border:1,
					html:"asdasd",
					baseCls:"pie"
				}

			]

		}


	]

   


});