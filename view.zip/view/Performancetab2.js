Ext.define("Threesixtydashboard.view.Performancetab2",{
	layout:"fit",
	extend:"Ext.tab.Panel",
	require:["Threesixtydashboard.view.SnapshotSelector"],
	alias:"widget.performancetabpanel",
	bodyPadding:10,
	overflow:"auto",
	items:[
			{
				items:[
					{
						xtype:"panel",
						bodyPadding:20,
						width:600,
						height:400,
						border:1,
						layout:"card",
						tbar:[
							{
								xtype:'button',
								text:"Collateral",
								handler:function()
								{
								arguments[0].up("panel").setActiveItem(0);
								}
							},
							{
								xtype:'button',
								text:"Facility",
								handler:function()
								{
								arguments[0].up("panel").setActiveItem(1);
								}
							}

						],
						items:[
					
							{
								xtype:"collateralgraph"
							},
							{
								xtype:'facilityGraph'
							}


						]
					}



				]


			}

	]});