Ext.define("Threesixtydashboard.view.Reporter",{
	alias:"widget.reporter",
	extend:"Ext.container.Container",
	width:"100%",
	overflow:"auto",
	layout:"vbox",
	items:[
			{
				xtype:"container",
				layout:"hbox",
				width:"100%",
				height:380,
				items:[
					{xtype:"container",
					width:"70%",
					height:380,
					baseCls:"dataholder",
					items:[
						{xtype:"performancebar",height:360,width:"100%"}

					]

					},
					{xtype:"container",
					width:"28%",
					height:380,
					baseCls:"dataholder",
					items:[
						{xtype:"pie-donut"}
					]


					}


				]
			},
			{
				xtype:"container",
				layout:"hbox",
				width:"100%",
				items:[
					{xtype:"container",width:"70%",height:300,baseCls:"dataholder",overflow:"scroll",items:[{xtype:"reqgrid"}]},
					{xtype:"container",width:"28%",height:300,baseCls:"dataholder"}


				]
			}


	]});
	