Ext.define("Threesixtydashboard.view.Peformancebar",{
	alias:"widget.performancebar",
	extend: 'Ext.Panel',
	controller:"perfcontroller",
	
	overflow:"scroll",
	 width: "100%",
    height: 360,

	items:{
		xtype:"cartesian",
	
		height:360,

		reference:"chart",
		store:{
			type:"snapstore"
		},
		insetPadding:{
			 top: 40,
            bottom: 40,
            left: 20,
            right: 40

		},
		interactions:{
				type:"itemedit",
				tooltip:{
					renderer:"onEditTipRender"
				},
				renderer:"onColumnEdit"

		},
		axes:[
			{
				type:"numeric",
				position:"left",
				minimum:200,
				titleMargin:10,
				title:{
					text:"Latency",
					fontWeight:800
				},
				listeners:{
					rangechange:"onAxisRangeChange"
				}
			},
			{
				type:"numeric",
				position:"bottom",
				titleMargin:20,
				minimum:0,
				title:{
					text:"Time",
					fontWeight:800
				}
			}



		],
		series:{
			type:"bar",

			xField:"timeline",
			yField:"latency",
		
		highlight: {
                strokeStyle: 'black',
                fillStyle: 'gold'
            }, label: {
                field: 'highF',
                display: 'insideEnd',
                renderer: 'onSeriesLabelRender'
            }},
	sprites:{
		type:"text",
		text:"Request Summary",
		fontSize:18,
		fontWeight:800,
		width:200,
		height:22,
		x:40,
		y:20
	},
	listeners: {
            afterrender: 'onAfterRender',
            beginitemedit: 'onBeginItemEdit',
            enditemedit: 'onEndItemEdit'
        }
}
}
	);
	