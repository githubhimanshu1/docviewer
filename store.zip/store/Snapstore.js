Ext.define('Threesixtydashboard.store.Snapstore', {
    extend: 'Ext.data.Store',
    autoload:true,
    alias: 'store.snapstore',

    fields: [
        'name', 'latency', 'module','timeline'
    ],

    data: { items: [
       {name:"a",latency:2431,module:"rdm",timeline:432},
         {name:"a",latency:231,module:"rdm",timeline:332},
           {name:"a",latency:431,module:"rdm",timeline:532},
             {name:"a",latency:1231,module:"rdm",timeline:782},
             {name:"a",latency:2541,module:"rdm",timeline:342},
         {name:"a",latency:41,module:"rdm",timeline:862},
           {name:"a",latency:89,module:"rdm",timeline:1232},
             {name:"a",latency:567,module:"rdm",timeline:1432},
                 {name:"a",latency:234,module:"rdm",timeline:2432},
         {name:"a",latency:754,module:"rdm",timeline:4832},
           {name:"a",latency:234,module:"rdm",timeline:932},
             {name:"a",latency:895,module:"rdm",timeline:1332},
             {name:"a",latency:234,module:"rdm",timeline:122},
         {name:"a",latency:544,module:"rdm",timeline:562},
           {name:"a",latency:875,module:"rdm",timeline:532},
             {name:"a",latency:986,module:"rdm",timeline:784},
                 {name:"a",latency:923,module:"rdm",timeline:756},
         {name:"a",latency:862,module:"rdm",timeline:864},
           {name:"a",latency:424,module:"rdm",timeline:823},
             {name:"a",latency:123,module:"rdm",timeline:976},
             {name:"a",latency:756,module:"rdm",timeline:345},
         {name:"a",latency:863,module:"rdm",timeline:634},
           {name:"a",latency:975,module:"rdm",timeline:654},
             {name:"a",latency:3241,module:"rdm",timeline:431}


       ]
    },

    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            rootProperty: 'items'
        }
    }
});
