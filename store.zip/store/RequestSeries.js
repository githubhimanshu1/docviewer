Ext.define('Threesixtydashboard.view.RequestSeries', {
    extend: 'Ext.Panel',
    xtype: 'pie-donut',
    controller: 'pie-basic',
    bodyPadding:0,
    width: 330,

    tbar: [
        '->',
        {
            text: 'Preview',
            handler: 'onPreview'
        }
    ],

    items: [{
        xtype: 'polar',
        reference: 'chart',
        width: '100%',
        height: 250,
        
        innerPadding: 10,
        store: {
            type: 'mobile-os'
        },
        legend: {
            docked: 'bottom'
        },
        interactions: ['rotate', 'itemhighlight'],
        sprites: [ {
            type: 'text',
            text: 'Data: IDC Predictions - 2017',
            x: 12,
            y: 225
        }, {
            type: 'text',
            text: 'Source: Internet',
            x: 12,
            y: 440
        }],
        series: [{
            type: 'pie',
            angleField: 'data1',
            donut: 40,
            label: {
                field: 'os',
                display: 'outside'
            },
            highlight: true,
            tooltip: {
                trackMouse: true,
                renderer: 'onSeriesTooltipRender'
            }
        }]
    }]

});